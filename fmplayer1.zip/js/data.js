let songs = [
    {
        name: 'Italo Disco',
        path: 'https://ssl-1.radiohost.pl:8018/stream',
        artist: 'Italo4You',
        cover: 'images/cover/1.jpg'
    },
    


{
        name: '80S Disco',
        path: 'https://pub0102.101.ru:8443/stream/personal/aacp/64/1781512?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJrZXkiOiIwNjBhYzBkMDMzZDExZjg0NTFhM2NiNjlmOTA1NTlkYyIsIklQIjoiMTg4LjE2Mi4xNDIuMTk4IiwiVUEiOiJNb3ppbGxhXC81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXRcLzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZVwvMTAzLjAuMC4wIFNhZmFyaVwvNTM3LjM2IiwiUmVmIjoiaHR0cHM6XC9cLzEwMS5ydVwvIiwidWlkX2NoYW5uZWwiOiIxNzgxNTEyIiwidHlwZV9jaGFubmVsIjoicGVyc29uYWwiLCJ0eXBlRGV2aWNlIjoiUEMiLCJCcm93c2VyIjoiQ2hyb21lIiwiQnJvd3NlclZlcnNpb24iOiIxMDMuMC4wLjAiLCJTeXN0ZW0iOiJXaW5kb3dzIDEwIiwiZXhwIjoxNjU3NTg0Mzg3fQ.BeKQXembGRdmwlOYGJyWyZJnKDgjqU7LHt6gVHtcaMo',
        artist: 'Denis Disco',
        cover: 'images/cover/ed80.jpg'
    },



{
        name: 'news radio',
        path: 'https://icecast-vgtrk.cdnvideo.ru/vestifm_aac_32kbps',
        artist: 'Vesti FM',
        cover: 'images/cover/vesti-fm.jpg'
    },
    {
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1525/stream',
        artist: 'New Generation',
        cover: 'images/cover/new.png'
    },
    {
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1385/stream',
        artist: 'Disco Classic',
        cover: 'images/cover/classic.png'
    },
    {
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1565/stream',
        artist: 'Euro Disco',
        cover: 'images/cover/euro-disco.png'
    },

{
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1615/stream',
        artist: 'Synthesizer Dance',
        cover: 'images/cover/synt.png'
    },

{
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1635/stream',
        artist: '80s Gold',
        cover: 'images/cover/80s.png'
    },












]