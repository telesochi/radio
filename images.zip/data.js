let songs = [
    {
        name: 'Italo Disco',
        path: 'https://ssl-1.radiohost.pl:8018/stream',
        artist: 'ITALO4YOU',
        cover: 'images/cover/1.jpg'
    },
    


{
        name: 'Euro Disco 80s',
        path: 'https://pub0302.101.ru:8443/stream/personal/aacp/64/1781512?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJrZXkiOiI4YmY0OWI5ZTAzMWYwY2YwM2E3ZWY3OGIwZThkNjI5ZCIsIklQIjoiMTg1LjMuMzUuMzYiLCJVQSI6Ik1vemlsbGFcLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdFwvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lXC85Ny4wLjQ2OTIuOTkgU2FmYXJpXC81MzcuMzYiLCJ1aWRfY2hhbm5lbCI6IjE3ODE1MTIiLCJ0eXBlX2NoYW5uZWwiOiJwZXJzb25hbCIsInR5cGVEZXZpY2UiOiJQQyIsIkJyb3dzZXIiOiJDaHJvbWUiLCJCcm93c2VyVmVyc2lvbiI6Ijk3LjAuNDY5Mi45OSIsIlN5c3RlbSI6IldpbmRvd3MgMTAiLCJleHAiOjE2NDMwMDAwNjR9.Dsd2nKjIBciRivZ298CwFCyaKsTioUvsBT24AeJTrNM',
        artist: 'eurodisco80s.101.RU',
        cover: 'images/cover/ed80.jpg'
    },



{
        name: 'news radio',
        path: 'https://icecast-vgtrk.cdnvideo.ru/vestifm_aac_32kbps',
        artist: 'Vesti FM',
        cover: 'images/cover/vesti-fm.jpg'
    },
    {
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1525/stream',
        artist: 'New Generation',
        cover: 'images/cover/new.png'
    },
    {
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1385/stream',
        artist: 'Disco Classic',
        cover: 'images/cover/classic.png'
    },
    {
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1565/stream',
        artist: 'Euro Disco',
        cover: 'images/cover/euro-disco.png'
    },

{
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1615/stream',
        artist: 'Synthesizer Dance',
        cover: 'images/cover/synt.png'
    },

{
        name: 'Italo Disco',
        path: 'https://ruby.torontocast.com:1635/stream',
        artist: '80s Gold',
        cover: 'images/cover/80s.png'
    },












]